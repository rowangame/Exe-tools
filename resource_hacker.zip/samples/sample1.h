#define IDC_ABOUT_BITMAP      100
#define IDC_ABOUT_TITLE       101
#define IDC_ABOUT_LINK        102
#define IDC_ABOUT_OKBTN       103

//uncomment the following line to see how the compiler handles errors inside nested INCLUDEs ...
//#defin MISSPELLED_DEFINE           

